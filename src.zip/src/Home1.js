import Home from "./Home"
const Notloggedhome=()=>{
    return(
        <>
        <Home/>
        </>
    )
}
export default Notloggedhome;