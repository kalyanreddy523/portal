import React from "react";
import "../node_modules/bootstrap/dist/css/bootstrap.css";
import "../node_modules/bootstrap/dist/js/bootstrap.js";

function Footer(){
    return(
        <>
        <div className="container-fluid bg-dark">
            <div className="row">
                <div className="col-12">
                    <p className="text-white text-center fw-bold pt-2">All @Copyrights Reserved</p>
                </div>
            </div>
        </div>
        </>
    )
}
export default Footer;