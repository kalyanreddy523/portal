let nameInputValue = '';

export const setNameInputValue = (value) => {
  nameInputValue = value;
};

export const getNameInputValue = () => {
  return nameInputValue;
};