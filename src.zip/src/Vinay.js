import React from "react";
import "./App.css";
function Sai(){
    return(
        <>
        <h1>sai kumar</h1>
        </>
    )
}
function Raj(){
    return(
        <>
        <h1 className="para">Raj kumar</h1>
        </>
    )
}
function Vinay(){
    return(
        <>
        <p>kjhasyuhjashj</p>
        </>
    )
}

export default Vinay;
export { Raj, Sai };

