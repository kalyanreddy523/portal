import Trainees from "./Trainees";
function Aboutus(){
return(
    <>
    <Trainees/>
    </>
)
}
export default Aboutus;