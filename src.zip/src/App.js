import "../node_modules/bootstrap/dist/css/bootstrap.css";
import "../node_modules/bootstrap/dist/js/bootstrap.js";
import "./App.css";
import Login from "./Login.js";


function App(){
return(
 <>
<Login/>
 
 </>
  
)
}

export default App;

 



